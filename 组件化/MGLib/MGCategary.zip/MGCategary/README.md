# MGCategary

[![CI Status](https://img.shields.io/travis/Maling1255/MGCategary.svg?style=flat)](https://travis-ci.org/Maling1255/MGCategary)
[![Version](https://img.shields.io/cocoapods/v/MGCategary.svg?style=flat)](https://cocoapods.org/pods/MGCategary)
[![License](https://img.shields.io/cocoapods/l/MGCategary.svg?style=flat)](https://cocoapods.org/pods/MGCategary)
[![Platform](https://img.shields.io/cocoapods/p/MGCategary.svg?style=flat)](https://cocoapods.org/pods/MGCategary)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MGCategary is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MGCategary'
```

## Author

Maling1255, maling@amberweather.com

## License

MGCategary is available under the MIT license. See the LICENSE file for more info.
