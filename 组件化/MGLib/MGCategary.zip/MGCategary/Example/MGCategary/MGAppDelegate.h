//
//  MGAppDelegate.h
//  MGCategary
//
//  Created by Maling1255 on 04/25/2020.
//  Copyright (c) 2020 Maling1255. All rights reserved.
//

@import UIKit;

@interface MGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
