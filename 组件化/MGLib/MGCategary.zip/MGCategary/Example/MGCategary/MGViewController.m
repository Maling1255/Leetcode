//
//  MGViewController.m
//  MGCategary
//
//  Created by Maling1255 on 04/25/2020.
//  Copyright (c) 2020 Maling1255. All rights reserved.
//

#import "MGViewController.h"
#import "UIView+Frame.h"

@interface MGViewController ()

@end

@implementation MGViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
//    self.view.width = 100
    
    [self.view test];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
