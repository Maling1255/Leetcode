//
//  main.m
//  MGCategary
//
//  Created by Maling1255 on 04/25/2020.
//  Copyright (c) 2020 Maling1255. All rights reserved.
//

@import UIKit;
#import "MGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MGAppDelegate class]));
    }
}
